
require(raster)
require(rgdal)
require(tidyverse)
require(rgeos)
require(gtools)
require(stringr)

OSys <- Sys.info(); OSys <- OSys[names(OSys)=='sysname']
if(OSys == 'Linux'){
  path <- '//mnt/Workspace_cluster_9/Coffee_Cocoa2/_cam' 
} else {
  if(OSys == 'Windows'){
    path <- '//dapadfs/Workspace_cluster_9/Coffee_Cocoa2/_cam'
  }
}

load(paste0(path, '/_rData/_run1/threshold_prob.rData'))
load(file = paste0(path, '/_rData/_run1/clusterpresdata.rData'))
years <- c('2030', '2050')
gcm <- 'current'
no.absenceclasses <- 2

limitations <- function(path_lyr_prob, path_lyr_clust, path_output, nameOutput, no.clusters, no.absenceclasses){
  
  require(raster)
  require(rgdal)
  require(tidyverse)
  
  lyr_prob  <- raster(path_lyr_prob)
  lyr_clust <- raster(path_lyr_clust)
  
  mtx_prob  <- matrix(c(0, threshold, 0, threshold, 1, 2), ncol = 3, byrow = T)
  mtx_clust <- matrix(c(0.5, no.absenceclasses + 0.5, 0, no.absenceclasses + 0.5, no.absenceclasses + no.clusters + 0.5, 1), nrow = 2, byrow = T)
  
  lyr_prob_rcl  <- raster::reclassify(lyr_prob, mtx_prob)
  lyr_clust_rcl <- raster::reclassify(lyr_clust, mtx_clust)
  
  diff <- lyr_prob_rcl - lyr_clust_rcl
  result <- lyr_clust
  result[which(diff[] == -1)] <- no.absenceclasses + no.clusters + 1
  result[which(diff[] == 2)]  <- no.absenceclasses + no.clusters + 1
  
  print('To Write')
  
  writeRaster(result, paste(path_output, nameOutput, sep = '/'))
  
}

paste0(path, '/_RF/_run1/_results/_raw/_current/RF_5Clust_Current.asc')

limitations(path_lyr_prob = paste0(path, '/_RF/_run1/_results/_raw/_current/RF_5Prob_current.asc'),
            path_lyr_clust = paste0(path, '/_RF/_run1/_results/_raw/_current/RF_5Clust_current2.asc'),
            path_output = paste0(path, '/_RF/_run1/_results/_raw/_current'),
            nameOutput = paste0('RF_', no.clusters, 'Clust_lim2_', gcm, '.asc'),
            no.absenceclasses = 2, 
            no.clusters = no.clusters)

