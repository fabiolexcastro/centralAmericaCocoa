

require(raster)
require(rgdal)
require(tidyverse)

OSys <- Sys.info(); OSys <- OSys[names(OSys)=='sysname']
if(OSys == 'Linux'){
  path <- '//mnt/Workspace_cluster_9/Coffee_Cocoa2/_cam' 
} else {
  if(OSys == 'Windows'){
    path <- '//dapadfs/Workspace_cluster_9/Coffee_Cocoa2/_cam'
  }
}

load(paste0(path, '/_rData/_run1/threshold_prob.rData'))
load(file = paste0(path, '/_rData/_run1/clusterpresdata.rData'))
gcm <- 'current'

mixedCategory <- function(pathClust, pathUnc, pathProb, path_output, threshold, no.absenceclasses){
  
  load(paste0(path, '/_rData/_run1/clusterpresdata.rData'))
  occ       <- norm[,1:2]
  # occ      <- read.csv(path_presences)
  lyrClust <- raster(pathClust)
  lyrUnc   <- raster(pathUnc)
  lyrProb  <- raster(pathProb)
  
  thrUnc   <- raster::extract(lyrUnc, occ[,1:2]) 
  thrUnc   <- thrUnc[!is.na(thrUnc)]
  thrUnc1  <- quantile(thrUnc, 0) %>% # Quantile 10%
                as.numeric()
  
  # values   <- raster::extract(lyrUnc, occ[,1:2])
  # quantile(values, seq(0,1,0.01))
  
  result <- lyrClust
  
  # result[which(lyrUnc[] < thrUnc & lyrProb[] > threshold)] <- max(unique(lyrClust[]), na.rm = T) + 1 # Be care!!!!! > o < ???
  result[which(lyrUnc[] < thrUnc1 & lyrProb[] > threshold)] <- max(unique(lyrClust[]), na.rm = T) + 1 # Be care!!!!! > o < ???
  
  print('To Write Raster')
  
  writeRaster(result, paste0(path_output, '/RF_', no.clusters, 'Classes_unc_', gcm, '.asc'), overwrite = T)
  
  return(result)
  
}

mixta <- mixedCategory(pathClust = paste0(path, '/_RF/_run1/_results/_raw/_current/RF_5Clust_lim2_current.asc'),
                       pathUnc = paste0(path, '/_RF/_run1/_results/_raw/_current/RF_5Unc_current.asc'),
                       pathProb = paste0(path, '/_RF/_run1/_results/_raw/_current/RF_5Prob_current.asc'),
                       path_output = paste0(path, '/_RF/_run1/_results/_raw/_current'),
                       threshold = threshold,
                       no.absenceclasses = 2)


occ       <- norm[,1:2]
pathUnc   <- paste0(path, '/_RF/_run1/_results/_raw/_current/RF_5Unc_current.asc')

thrUnc         <- raster::extract(raster(pathUnc), occ[,1:2]) %>%
                      quantile(0.0) %>% # Quantile 10%
                      as.numeric()

save(thrUnc, file = paste0(path, '/_rData/_run1/threshold_unc.rData'))

